#include<stdio.h>
int main()
{
    char A[7];
    scanf("%s",&A);
    printf("%c%c/%c%c/%c%c\n",A[3],A[4],A[0],A[1],A[6],A[7]);
    printf("%c%c/%c%c/%c%c\n",A[6],A[7],A[3],A[4],A[0],A[1]);
    printf("%c%c-%c%c-%c%c\n",A[0],A[1],A[3],A[4],A[6],A[7]);
    return 0;
}
