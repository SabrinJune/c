#include<stdio.h>
int main()
{
    //2755
    printf("\"Ro'b'er\tto\\/\"\n(._.) ( l: ) ( .-. ) ( :l ) (._.)\n(^_-) (-_-) (-_^)\n(\"_\") ('.')\n");
    return 0;

}
