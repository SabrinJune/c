#include<stdio.h>
int main()
{
    double A;
    scanf("%lf",&A);
    int B=A;
    A = (A-B)*10000;
    printf("%.0lf.%d\n",A,B);
    return 0;
}
