#include <stdio.h>

int main()
{
   int i,c;
   for(i=0;i<39;i++)
   {
       printf("-");
   }
   printf("\n");
   for(i=1;i<=39;i++)
   {
       if(i==1 || i==13 || i==23 || i==39 || i==4 || i==16 || i==26)
       {
           printf("*");
        }
       else
        {
            printf(" ");
        }
   }
   printf("\n");
   for(i=0;i<39;i++)
   {
       printf("-");
   }
   printf("\n");
   for(c=0;c<=15;c++)
    {
    for(i=1;i<=39;i++)
   {
       if(i==1 || i==13 || i==23 || i==39 || i==8 || i==18 || i==31)
       {
           printf("*");
        }
       else
        {
            printf(" ");
        }
   }
   printf("\n");
   }
   for(i=0;i<39;i++)
   {
       printf("-");
   }
   printf("\n");

    getch();
}
