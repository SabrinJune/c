#include<stdio.h>
int main()
{
    int A;
    unsigned int B,C;
    scanf("%5d %2u %3u",&A,&B,&C);
    printf("A = %d, B = %u, C = %u\nA = %10d, B = %10u, C = %10u\nA = %010d, B = %010u, C = %010u\nA = %-10d, B = %-10u, C = %-10u\n",A,B,C,A,B,C,A,B,C,A,B,C);
    return 0;

}

