#include<stdio.h>
int main()

{


    printf("---------------------------------------\n");
    printf("|x = 35                               |\n");
    printf("|                                     |\n");
    printf("|               x = 35                |\n");
    printf("|                                     |\n");
    printf("|                               x = 35|\n");
    printf("---------------------------------------\n");
    return 0;

}
