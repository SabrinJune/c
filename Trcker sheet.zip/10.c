#include<stdio.h>
int main()
{
    printf("       A\n      B B\n     C   C\n    D     D\n   E       E\n    D     D\n     C   C\n      B B\n       A\n");
    return 0;

}
